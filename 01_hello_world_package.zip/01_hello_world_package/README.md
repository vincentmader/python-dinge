# 01 – Hello World as an installable package (offline install with uv)

The Hello World server packaged the way real Python tools are: a **package with a command name** (`hello-mcp`). It's shipped to an offline machine as **one archive** and installed with **one `uv` command**.

Compared with the other two variants:

|                         | `01_hello_world`         | `01_hello_world_offline`        | this folder                          |
| ----------------------- | ------------------------ | ------------------------------- | ------------------------------------ |
| Needs internet at start | yes (uv downloads `mcp`) | no                              | no                                   |
| Needs on target         | uv + internet            | python3                         | uv + python3                         |
| What you transfer       | –                        | the whole folder (~30 MB)       | **one `.tar.gz` (~10 MB)**           |
| Server started via      | `uv run --script server.py` | `python3 server.py`          | **`hello-mcp`** (a command on PATH)  |

## Why not just one wheel?

A wheel is the standard Python package file, but by design **a wheel can't contain its dependencies**. It only lists them, and the installer fetches them. So the archive contains a *wheelhouse*: our own wheel plus one wheel per dependency. `uv` installs from that folder with networking off.

## Files

| File                          | Role                                                                     |
| ----------------------------- | ------------------------------------------------------------------------ |
| `pyproject.toml`              | Package definition: name, version, dependency `mcp==2.3.0`, and the two commands. |
| `src/hello_mcp/server.py`     | The server (same as step 01). `main()` is the `hello-mcp` command.      |
| `src/hello_mcp/selftest.py`   | `hello-mcp-selftest`: starts the installed server and calls `say_hello`. |
| `build_offline.sh`            | Run on the **online** machine: builds the archive for a target.         |
| `opencode.json`               | Starts the server via the `hello-mcp` command.                          |
| `dist/*.tar.gz`               | The result: the one file to transfer.                                   |

## Steps

**1. On the offline machine:** check the Python version and architecture:

```sh
python3 --version   # e.g. 3.12
uname -m            # x86_64 or aarch64
uv --version
```

**2. On the online machine:** build the archive:

```sh
./build_offline.sh 3.12 x86_64
# → dist/hello-mcp-0.1.0-py312-x86_64.tar.gz
```

It contains:

```
hello-mcp-0.1.0-py312-x86_64/
├── wheelhouse/      hello_mcp-0.1.0-py3-none-any.whl + 28 dependency wheels
├── install.sh       uv tool install --offline --no-index --find-links wheelhouse ...
└── opencode.json
```

**3. On the offline machine:** unpack, install, test:

```sh
tar xzf hello-mcp-0.1.0-py312-x86_64.tar.gz
cd hello-mcp-0.1.0-py312-x86_64
./install.sh
hello-mcp-selftest      # → result: Hello, Vincent! ...
opencode mcp list       # → ✓ hello connected
```

`uv tool install` creates its own isolated environment for the tool (in `~/.local/share/uv/tools/hello-mcp/`) and puts the commands into `~/.local/bin/`.

## Things to know

- **`~/.local/bin` must be on the PATH**, also for opencode, otherwise opencode can't find `hello-mcp`. Check with `which hello-mcp`. If it's missing, run `uv tool update-shell` (then open a new shell), or put the full path into `opencode.json`: `"command": ["/home/<you>/.local/bin/hello-mcp"]`.
- **The archive must match the target**, as in the `vendor/` variant. The compiled dependencies (`pydantic_core`, `rpds`, `cffi`) only work with one Python minor version and one CPU architecture. With `--python 3.12`, `uv` uses the machine's existing Python 3.12. Offline it can't download one.
- **Updates:** raise `version` in `pyproject.toml`, rebuild, transfer, and run `./install.sh` again (it uses `--force`).
- **Without uv** the same wheelhouse works with plain pip:
  ```sh
  python3 -m venv ~/hello-mcp-venv
  ~/hello-mcp-venv/bin/pip install --no-index --find-links wheelhouse hello-mcp
  ```
- **Tested** in an x86_64 Linux container (`ghcr.io/astral-sh/uv:python3.12-bookworm-slim`) started with `--network none`: install and `hello-mcp-selftest` work.

## Even more "single file": a zipapp

If one *executable* file without any installation is the goal, tools like [`shiv`](https://github.com/linkedin/shiv) or [`pex`](https://github.com/pex-tool/pex) pack the server **and** all dependencies into one `hello-mcp.pyz` that runs with `python3 hello-mcp.pyz`. The same platform-matching rules apply. The wheel-based approach in this folder is the more standard one, and it's how later steps can be shipped too.
