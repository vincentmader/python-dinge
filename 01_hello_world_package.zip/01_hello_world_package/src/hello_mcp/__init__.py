"""Hello World MCP server, packaged."""
