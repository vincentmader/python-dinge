"""`hello-mcp-selftest`: start the installed server and call say_hello.

Shipped inside the package, so the installation can be checked on the target
machine without opencode, the Inspector, or internet.
"""

import asyncio
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def _run() -> None:
    # Start the server with this same Python (the tool's own environment).
    params = StdioServerParameters(command=sys.executable, args=["-m", "hello_mcp.server"])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            for tool in (await session.list_tools()).tools:
                print(f"tool:   {tool.name}")
            result = await session.call_tool("say_hello", {"name": "Vincent"})
            print(f"result: {result.content[0].text}")


def main() -> None:
    asyncio.run(_run())
