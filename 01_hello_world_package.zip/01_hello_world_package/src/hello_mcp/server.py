"""The same Hello World server as step 01, as part of an installable package.

The `hello-mcp` command (see [project.scripts] in pyproject.toml) calls main().
"""

from mcp.server.mcpserver import MCPServer

mcp = MCPServer("hello")


@mcp.tool()
def say_hello(name: str) -> str:
    """Greet a person by name. Use this when the user asks to be greeted."""
    return f"Hello, {name}! This greeting comes from your own MCP server."


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
