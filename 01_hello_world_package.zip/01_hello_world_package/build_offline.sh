#!/usr/bin/env bash
# Run on a machine WITH internet. Produces ONE file for the offline machine:
#
#   dist/hello-mcp-<version>-py<ver>-<arch>.tar.gz
#     ├── wheelhouse/      our wheel + every dependency wheel, built for the target
#     ├── install.sh       installs offline with `uv tool install`
#     └── opencode.json    registers the installed `hello-mcp` command
#
# Usage:   ./build_offline.sh <python-version> <arch>
# Example: ./build_offline.sh 3.12 x86_64
set -euo pipefail

PYVER="${1:?usage: ./build_offline.sh <python-version, e.g. 3.12> <arch: x86_64|aarch64>}"
ARCH="${2:?usage: ./build_offline.sh <python-version, e.g. 3.12> <arch: x86_64|aarch64>}"
HERE="$(cd "$(dirname "$0")" && pwd)"
VERSION="$(sed -n 's/^version = "\(.*\)"/\1/p' "$HERE/pyproject.toml")"
NAME="hello-mcp-$VERSION-py${PYVER/./}-$ARCH"
STAGE="$HERE/build/$NAME"

rm -rf "$HERE/build" && mkdir -p "$STAGE/wheelhouse" "$HERE/dist"

# 1. Our own package -> a wheel (pure Python, works everywhere).
uv build --wheel --out-dir "$STAGE/wheelhouse" "$HERE"
rm -f "$STAGE/wheelhouse/.gitignore"

# 2. All dependencies of that wheel, as wheels for the TARGET platform.
python3 -m pip download \
  --dest "$STAGE/wheelhouse" \
  --python-version "$PYVER" \
  --implementation cp \
  --platform "manylinux2014_$ARCH" \
  --platform "manylinux_2_17_$ARCH" \
  --platform "manylinux_2_28_$ARCH" \
  --only-binary=:all: \
  --disable-pip-version-check \
  --quiet \
  "$STAGE"/wheelhouse/hello_mcp-*.whl

# 3. Installer + opencode config.
cat > "$STAGE/install.sh" <<EOF
#!/usr/bin/env bash
# Offline install of hello-mcp. Needs: uv, and Python $PYVER on this machine.
set -euo pipefail
HERE="\$(cd "\$(dirname "\$0")" && pwd)"
uv tool install --force --offline --no-index \\
  --find-links "\$HERE/wheelhouse" \\
  --python "$PYVER" \\
  hello-mcp
echo
echo "Installed. Check with:  hello-mcp-selftest"
EOF
chmod +x "$STAGE/install.sh"
cp "$HERE/opencode.json" "$STAGE/"

# 4. Pack into one file. COPYFILE_DISABLE / --no-xattrs: keep macOS metadata
#    out of the archive (Linux tar would warn about it).
COPYFILE_DISABLE=1 tar --no-xattrs -czf "$HERE/dist/$NAME.tar.gz" -C "$HERE/build" "$NAME"
echo
echo "Built: dist/$NAME.tar.gz ($(du -h "$HERE/dist/$NAME.tar.gz" | cut -f1), $(ls "$STAGE/wheelhouse" | wc -l | tr -d ' ') wheels)"
